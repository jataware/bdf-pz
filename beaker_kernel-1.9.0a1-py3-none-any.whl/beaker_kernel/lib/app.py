from dataclasses import dataclass, field, asdict
import os
import json
import typing


@dataclass
class BeakerAppAsset:
    slug: str
    src: str
    attrs: dict[str, str]

    def __init__(self, slug, src, **kwargs):
        self.slug = slug
        self.src = src
        self.attrs = kwargs


@dataclass
class AppConfigStrings:
    short_title: str|None
    chat_welcome_html: str|None


@dataclass
class BeakerAppConfig:
    assets: list[BeakerAppAsset]
    default_context: str|None
    single_context: bool
    stylesheets: list[dict[str, str]]
    strings: AppConfigStrings


@dataclass
class Context:
    slug: str
    payload: dict[str, any] = field(default_factory=lambda: {})


class BeakerApp:
    SLUG: typing.ClassVar[str]
    ASSET_DIR: typing.ClassVar[os.PathLike|None] = None

    assets: list[BeakerAppAsset] = []
    default_context: Context|None = None
    single_context: bool = False
    stylesheets: list[dict[str, str]] = []
    strings: AppConfigStrings|None = None
    pages: dict[str, dict]

    def __init__(self):
        for asset in self.__class__.assets:
            asset.src = os.path.join("/assets", self.SLUG, asset.src)

    def to_javascript(self) -> str:
        output = [
            "window.beaker_app = {};"
        ]

        if hasattr(self, 'page_title'):
            output.append(
                f"""document.title = {json.dumps(self.page_title)};"""
            )

        if self.pages:
            output.append(
                f"""window.beaker_app.pages = {json.dumps(self.pages)};"""
            )
        if self.strings:
            output.append(
                f"""window.beaker_app.templateStrings = {json.dumps(asdict(self.strings))};"""
            )
        if self.default_context:
            output.append(
                f"""window.beaker_app.default_context = {json.dumps(asdict(self.default_context))};"""
            )
        if self.single_context:
            output.append(
                f"""window.beaker_app.single_context = {json.dumps(self.single_context)};"""
            )
        if self.assets:
            output.append(
                f"""window.beaker_app.assets = {json.dumps({asset.slug: asdict(asset) for asset in self.assets})};"""
            )
        for idx, stylesheet in enumerate(self.stylesheets):
            output.append(
                f"""\
let style{idx} = document.createElement("style");
style{idx}.type = "text/css";
style{idx}.textContents = `{stylesheet}`;
document.head.appendChild(style{idx});
"""
            )
        return "\n".join(output)
